let express=require("express");
let app=express();
app.use(logger)
app.get("/books",(req,res)=>{
    return res.send({route:"/books"})
})
app.get("/libraries",arvind("librarian"),(req,res)=>{
    return res.send({route:"/libraries",permissions:req.permissions})
})
app.get("/authors",arvind("author"),(req,res)=>{
    return res.send({route:"/authors",permissions:req.permissions})
})

function logger(req,res,next){
    if(req.path=="/books"){
        req.permissions=true;
    }
    else if(req.path=="/libraries"){
        req.permissions=true;
    }
    else if(req.path=="/authors"){
        req.permissions=true;
    }
    else{
        req.permissions="Somebody else";
    }
    next()
}

function arvind(a){

    return function checkPermissions(req,res,next){
        if(req.path=="/authors"){
            next()
        }
        else if(req.path=="/libraries"){
            next()
        }
        else{
            req.role="Somebody else";
        }
    }
}

app.listen(4000,()=>{
    console.log("This is route handeller 4000")
})

